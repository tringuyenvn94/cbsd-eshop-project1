-- phpMyAdmin SQL Dump
-- version 2.10.3
-- http://www.phpmyadmin.net
-- 
-- โฮสต์: localhost
-- เวลาในการสร้าง: 
-- รุ่นของเซิร์ฟเวอร์: 5.0.51
-- รุ่นของ PHP: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- ฐานข้อมูล: `cbsdeshop`
-- 

-- --------------------------------------------------------

-- 
-- โครงสร้างตาราง `cart`
-- 

CREATE TABLE `cart` (
  `cid` int(11) NOT NULL auto_increment,
  `uid` int(11) NOT NULL,
  `confirmStatus` int(11) NOT NULL,
  `paidStatus` int(11) NOT NULL,
  `confirmDate` date NOT NULL,
  `paidDate` date NOT NULL,
  `paymentMethod` varchar(20) collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`cid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=38 ;

-- 
-- dump ตาราง `cart`
-- 

INSERT INTO `cart` VALUES (36, 36, 1, 0, '2014-01-24', '1992-03-31', 'Paypal');
INSERT INTO `cart` VALUES (35, 36, 1, 0, '2014-01-24', '1992-03-31', 'Credit Card');
INSERT INTO `cart` VALUES (28, 36, 1, 0, '2014-01-24', '1992-03-31', 'Paypal');
INSERT INTO `cart` VALUES (29, 36, 1, 0, '2014-01-24', '1992-03-31', 'Credit Card');
INSERT INTO `cart` VALUES (30, 37, 1, 0, '2014-01-24', '1992-03-31', 'Transfer');
INSERT INTO `cart` VALUES (31, 37, 0, 0, '1992-03-31', '1992-03-31', ' ');
INSERT INTO `cart` VALUES (32, 38, 1, 0, '2014-01-24', '1992-03-31', 'Credit Card');
INSERT INTO `cart` VALUES (33, 38, 1, 0, '2014-01-24', '1992-03-31', 'Transfer');
INSERT INTO `cart` VALUES (34, 38, 0, 0, '1992-03-31', '1992-03-31', ' ');
INSERT INTO `cart` VALUES (37, 36, 0, 0, '1992-03-31', '1992-03-31', ' ');

-- --------------------------------------------------------

-- 
-- โครงสร้างตาราง `cart_product`
-- 

CREATE TABLE `cart_product` (
  `cpid` int(11) NOT NULL auto_increment,
  `cid` int(11) NOT NULL,
  `pid` int(11) NOT NULL,
  `pname` varchar(50) collate utf8_unicode_ci NOT NULL,
  `amount` int(11) NOT NULL,
  `productPrice` double NOT NULL,
  PRIMARY KEY  (`cpid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=51 ;

-- 
-- dump ตาราง `cart_product`
-- 

INSERT INTO `cart_product` VALUES (27, 28, 30, 'SG60603WF VIOLET', 1, 140);
INSERT INTO `cart_product` VALUES (28, 28, 38, 'OT87151TH BRUSCHED SILVER', 1, 99);
INSERT INTO `cart_product` VALUES (50, 36, 28, 'SG603885JO RED ORANGE', 1, 200);
INSERT INTO `cart_product` VALUES (47, 35, 28, 'SG603885JO RED ORANGE', 1, 200);
INSERT INTO `cart_product` VALUES (48, 35, 29, 'SG601WF BLACK', 12, 160);
INSERT INTO `cart_product` VALUES (29, 29, 26, 'SG0365CM GRAY BLACK', 2, 99);
INSERT INTO `cart_product` VALUES (30, 29, 37, 'OT70195TH DEMI SHINY GRAY', 2, 89);
INSERT INTO `cart_product` VALUES (31, 30, 30, 'SG60603WF VIOLET', 1, 140);
INSERT INTO `cart_product` VALUES (32, 30, 28, 'SG603885JO RED ORANGE', 1, 200);
INSERT INTO `cart_product` VALUES (33, 30, 24, 'SG0207AT GOLD BLACK', 1, 119);
INSERT INTO `cart_product` VALUES (34, 30, 36, 'OT52425IC VIOLET PINK', 1, 110);
INSERT INTO `cart_product` VALUES (35, 30, 34, 'OT6996HS BLUE TEMPLE', 1, 109);
INSERT INTO `cart_product` VALUES (36, 32, 33, 'OT5225HS BLACK', 1, 119);
INSERT INTO `cart_product` VALUES (37, 32, 35, 'OT51542IC RED AVANA', 1, 110);
INSERT INTO `cart_product` VALUES (38, 32, 29, 'SG601WF BLACK', 1, 160);
INSERT INTO `cart_product` VALUES (39, 32, 31, 'OT5284AF BLACK GREEN', 1, 100);
INSERT INTO `cart_product` VALUES (40, 32, 28, 'SG603885JO RED ORANGE', 1, 200);
INSERT INTO `cart_product` VALUES (41, 33, 29, 'SG601WF BLACK', 1, 160);
INSERT INTO `cart_product` VALUES (42, 33, 38, 'OT87151TH BRUSCHED SILVER', 1, 99);
INSERT INTO `cart_product` VALUES (43, 33, 37, 'OT70195TH DEMI SHINY GRAY', 1, 89);
INSERT INTO `cart_product` VALUES (44, 33, 34, 'OT6996HS BLUE TEMPLE', 1, 109);
INSERT INTO `cart_product` VALUES (45, 33, 36, 'OT52425IC VIOLET PINK', 1, 110);

-- --------------------------------------------------------

-- 
-- โครงสร้างตาราง `product`
-- 

CREATE TABLE `product` (
  `id` int(11) NOT NULL auto_increment,
  `pname` varchar(50) collate utf8_unicode_ci NOT NULL,
  `description` varchar(1000) collate utf8_unicode_ci NOT NULL,
  `price` double NOT NULL,
  `amount` int(11) NOT NULL,
  `date` date NOT NULL,
  `typeid` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=43 ;

-- 
-- dump ตาราง `product`
-- 

INSERT INTO `product` VALUES (29, 'SG601WF BLACK', 'Style : WAYFARER', 160, -16, '2014-01-23', 63);
INSERT INTO `product` VALUES (28, 'SG603885JO RED ORANGE', 'Style : JAKKIE OHH', 200, 3, '2014-01-23', 63);
INSERT INTO `product` VALUES (30, 'SG60603WF VIOLET', 'Style : WAYFARER', 140, 3, '2014-01-23', 63);
INSERT INTO `product` VALUES (31, 'OT5284AF BLACK GREEN', 'Style : ACTIVE LIFESTYLE', 100, 9, '2014-01-23', 64);
INSERT INTO `product` VALUES (32, 'OT6156AF METAL BLACK', 'Style : ACTIVE LIFESTYLE', 129, 10, '2014-01-23', 64);
INSERT INTO `product` VALUES (33, 'OT5225HS BLACK', 'Style : HIGHSTREET', 119, 9, '2014-01-23', 64);
INSERT INTO `product` VALUES (34, 'OT6996HS BLUE TEMPLE', 'Style : HIGHSTREET', 109, 8, '2014-01-23', 64);
INSERT INTO `product` VALUES (23, 'SG14913AT GOLD ORANGE', 'Style : AVIATOR', 220, 10, '2014-01-23', 63);
INSERT INTO `product` VALUES (24, 'SG0207AT GOLD BLACK', 'Style : AVIATOR', 119, 9, '2014-01-23', 63);
INSERT INTO `product` VALUES (25, 'SG901CM Black', 'Style : CLUBMASTER', 119, 10, '2014-01-23', 63);
INSERT INTO `product` VALUES (26, 'SG0365CM GRAY BLACK', 'Style : CLUBMASTER', 99, 8, '2014-01-23', 63);
INSERT INTO `product` VALUES (27, 'SG71071JO HAVANA', 'Style : JAKKIE OHH', 200, 10, '2014-01-23', 63);
INSERT INTO `product` VALUES (35, 'OT51542IC RED AVANA', 'Style : ICON', 110, 9, '2014-01-23', 64);
INSERT INTO `product` VALUES (36, 'OT52425IC VIOLET PINK', 'Style : ICON', 110, 8, '2014-01-23', 64);
INSERT INTO `product` VALUES (37, 'OT70195TH DEMI SHINY GRAY', 'Style : TECH', 89, 7, '2014-01-23', 64);
INSERT INTO `product` VALUES (38, 'OT87151TH BRUSCHED SILVER', 'Style : TECH', 99, 8, '2014-01-23', 64);
INSERT INTO `product` VALUES (42, 'Snn', 'sun', 111, 1, '2014-01-24', 66);

-- --------------------------------------------------------

-- 
-- โครงสร้างตาราง `producttype`
-- 

CREATE TABLE `producttype` (
  `id` int(11) NOT NULL auto_increment,
  `ptname` varchar(30) collate utf8_unicode_ci NOT NULL,
  `description` varchar(100) collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=67 ;

-- 
-- dump ตาราง `producttype`
-- 

INSERT INTO `producttype` VALUES (63, 'Sunglasses', '--');
INSERT INTO `producttype` VALUES (64, 'Optic Glasses', '--');
INSERT INTO `producttype` VALUES (66, 'TV', '');

-- --------------------------------------------------------

-- 
-- โครงสร้างตาราง `user`
-- 

CREATE TABLE `user` (
  `id` int(11) NOT NULL auto_increment,
  `uname` varchar(20) collate utf8_unicode_ci NOT NULL,
  `surname` varchar(20) collate utf8_unicode_ci NOT NULL,
  `username` varchar(16) collate utf8_unicode_ci NOT NULL,
  `password` varchar(16) collate utf8_unicode_ci NOT NULL,
  `email` varchar(50) collate utf8_unicode_ci NOT NULL,
  `tel` varchar(13) collate utf8_unicode_ci NOT NULL,
  `address` varchar(100) collate utf8_unicode_ci NOT NULL,
  `userType` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=41 ;

-- 
-- dump ตาราง `user`
-- 

INSERT INTO `user` VALUES (38, 'Kewalin', 'Chaiyamoon', 'pndpanda', 'pnd99', 'panda@gmail.com', '0879091234', '55/7 m6 Sonklang Sankampang Chiang Mai 50130', 1);
INSERT INTO `user` VALUES (37, 'Wuthipong', 'Keawboonsom', 'tee99', '99tee', 'teetee@hotmail.com', '0888896321', '99/9 The urbana Paded Hangdong  Chiang Mai 50900', 1);
INSERT INTO `user` VALUES (36, 'Putsacha', 'Owatsakul', 'somcheng', 'sc1234', 'somcheng@gmail.com', '0812344691', '37 m1 meung Lumphun 50200', 1);
INSERT INTO `user` VALUES (39, 'Teerapun', 'Jaikla', 'admin', 'admin', 'xxyesisaexx@gmail.com', '0846112543', '254', 0);
INSERT INTO `user` VALUES (40, 'Supanit', 'Paya', 'aaaa', 'aaaa', 'gg@gmail.com', '0846112543', '254', 1);
